#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

find_sdk() {
  local candidates=(
    "${ANDROID_HOME:-}"
    "${ANDROID_SDK_ROOT:-}"
    "$HOME/android-sdk"
    "$HOME/lib/android-sdk"
    "$HOME/lib/android-sdk-9123335"
    "$PREFIX/opt/android-sdk"
  )
  local sdk
  for sdk in "${candidates[@]}"; do
    if [ -n "$sdk" ] && [ -d "$sdk/platforms" ] && [ -d "$sdk/build-tools" ]; then
      printf '%s' "$sdk"
      return 0
    fi
  done
  return 1
}

SDK="$(find_sdk || true)"
if [ -z "$SDK" ]; then
  echo "ERROR: Android SDK was not found."
  echo
  echo "Your SDK must contain platforms/ and build-tools/."
  echo "Set ANDROID_HOME to the SDK root and run this script again."
  exit 1
fi

export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
printf 'sdk.dir=%s\n' "$SDK" > local.properties

echo "Using Android SDK: $SDK"
echo "Using Gradle: $(gradle --version | sed -n 's/^Gradle \(.*\)$/\1/p' | head -1)"

echo

# The Termux aapt2 binary can be experimental with AGP. Do not override the
# Maven/AGP aapt2 by default. Set USE_TERMUX_AAPT2=1 only if specifically needed.
if [ "${USE_TERMUX_AAPT2:-0}" = "1" ] && [ -x "$PREFIX/bin/aapt2" ]; then
  printf 'android.aapt2FromMavenOverride=%s\n' "$PREFIX/bin/aapt2" >> local.properties
  echo "Using Termux aapt2 override: $PREFIX/bin/aapt2"
else
  echo "Using the Android Gradle Plugin aapt2 (no Termux override)."
fi

gradle "$@"
