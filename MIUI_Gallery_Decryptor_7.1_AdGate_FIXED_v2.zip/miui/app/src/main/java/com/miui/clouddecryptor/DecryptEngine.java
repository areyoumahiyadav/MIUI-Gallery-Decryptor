package com.miui.clouddecryptor;
import javax.crypto.Cipher; import javax.crypto.spec.IvParameterSpec; import javax.crypto.spec.SecretKeySpec;
import java.io.*; import java.math.BigInteger;
public final class DecryptEngine {
 private static final int CHUNK_SIZE=1024*1024;
 private static final byte[] SECRET_KEY=new byte[]{0x30,(byte)0x82,0x04,0x6C,0x30,(byte)0x82,0x03,0x54,(byte)0xA0,0x03,0x02,0x01,0x02,0x02,0x09,0x00};
 private static byte[] counter(){BigInteger v=new BigInteger("22696201676385068962342234041843478898");byte[] r=v.toByteArray(),iv=new byte[16];int s=Math.max(0,r.length-16),n=Math.min(16,r.length);System.arraycopy(r,s,iv,16-n,n);return iv;}
 public interface ProgressCallback{void onProgress(long p,long t);}
 public static void decrypt(InputStream in,OutputStream out,long total,boolean header,ProgressCallback cb)throws Exception{
  Cipher c=Cipher.getInstance("AES/CTR/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(SECRET_KEY,"AES"),new IvParameterSpec(counter()));
  if(header){long hs=Math.max(Math.min(1024L,total),16L);byte[] h=read(in,(int)hs),d=c.update(h);if(d!=null)out.write(d);long p=h.length;byte[] b=new byte[CHUNK_SIZE];int n;while((n=in.read(b))!=-1){out.write(b,0,n);p+=n;if(cb!=null)cb.onProgress(p,total);}if(cb!=null)cb.onProgress(p,total);return;}
  byte[] b=new byte[CHUNK_SIZE];long p=0;int n;while((n=in.read(b))!=-1){byte[] d=c.update(b,0,n);if(d!=null)out.write(d);p+=n;if(cb!=null)cb.onProgress(p,total);}byte[] d=c.doFinal();if(d!=null&&d.length>0)out.write(d);if(cb!=null)cb.onProgress(p,total);
 }
 private static byte[] read(InputStream in,int n)throws IOException{byte[] a=new byte[n];int o=0,r;while(o<n&&(r=in.read(a,o,n-o))!=-1)o+=r;if(o==n)return a;byte[] b=new byte[o];System.arraycopy(a,0,b,0,o);return b;}
 private DecryptEngine(){}
}