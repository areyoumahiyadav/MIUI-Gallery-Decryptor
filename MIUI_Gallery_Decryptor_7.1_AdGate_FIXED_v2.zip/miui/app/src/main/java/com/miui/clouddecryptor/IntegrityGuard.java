package com.miui.clouddecryptor;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import java.security.MessageDigest;
import java.util.Locale;

/** Fail-closed check against the signing certificate used by the distributed build.
 * Replace EXPECTED_SHA256 with the SHA-256 fingerprint of the final release signing key.
 */
public final class IntegrityGuard {
    private IntegrityGuard() {}

    // IMPORTANT: replace this with the SHA-256 fingerprint of YOUR FINAL
    // release signing certificate before publishing. The old APK fingerprint
    // must not be reused automatically because Termux/Gradle debug keys vary.
    private static final String EXPECTED_SHA256 = "REPLACE_WITH_RELEASE_SHA256";

    public static boolean isOfficialBuild(Context context) {
        // Debug builds are allowed during development so Termux testing is not
        // accidentally locked by a different local debug keystore. Release
        // builds still require the exact configured signing certificate.
        if (com.miui.clouddecryptor.BuildConfig.DEBUG) return true;
        if (EXPECTED_SHA256.startsWith("REPLACE_WITH")) return false;
        try {
            PackageManager pm = context.getPackageManager();
            Signature[] signatures;
            if (Build.VERSION.SDK_INT >= 28) {
                signatures = pm.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES)
                        .signingInfo.getApkContentsSigners();
            } else {
                signatures = pm.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES).signatures;
            }
            if (signatures == null || signatures.length == 0) return false;
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String actual = hex(md.digest(signatures[0].toByteArray()));
            return EXPECTED_SHA256.replace(":", "").equalsIgnoreCase(actual.replace(":", ""));
        } catch (Exception e) {
            return false;
        }
    }

    private static String hex(byte[] bytes) {
        StringBuilder b = new StringBuilder(bytes.length * 3);
        for (byte x : bytes) b.append(String.format(Locale.US, "%02X:", x));
        return b.substring(0, b.length() - 1);
    }
}
