package com.miui.clouddecryptor;

import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.*;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.documentfile.provider.DocumentFile;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import com.google.android.gms.ads.MobileAds;

public class MainActivity extends Activity {
    private static final int REQ_FILE=1001, REQ_OUTPUT_TREE=1003, REQ_SAVE_AS=1013;
    private static final String PREFS="miui_settings";
    private static final String DEFAULT_ACCENT="#5C8DFF";

    private DrawerLayout drawer;
    private TextView tvAppTitle,tvInput,tvMode,tvProgress,tvOutput,tvStatus,tvSignatureState,tvPreviewInfo,tvDrawerOutput,tvSelectedCount,tvClass,tvOutputShort,tvPreviewBadge,tvFooter;
    private ProgressBar progress;
    private Button btnChooseFile,btnDecrypt,btnSave,btnClear;
    private LinearLayout signatureCard,previewCard;
    private ImageView previewImage;
    private ImageButton btnPreviewPlay,btnMenu,btnCloseDrawer,btnTheme;
    private TextView tvHomeTitleView;
    private View heroCard;
    private Uri inputUri,outputTreeUri;
    private String inputName;
    private File tempFile;
    private FormatDetector.Result detected;
    private final ArrayList<Uri> selectedUris=new ArrayList<>();
    private final ExecutorService pool=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private android.content.SharedPreferences prefs;
    private int accentColor;
    private RewardedAdGate rewardedAdGate;
    private boolean integrityLocked = false;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        applyUiMode(prefs.getBoolean("dark",true));
        setContentView(R.layout.activity_main);
        bind(); setupDrawer(); wire(); refreshUi(); applyAccent(); animateTitle();
        MobileAds.initialize(this, status -> main.post(() -> rewardedAdGate = new RewardedAdGate(this)));
        integrityLocked = !IntegrityGuard.isOfficialBuild(this);
    }

    private void requestNotificationPermissionIfNeeded(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7001);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==7001 && Build.VERSION.SDK_INT>=33 && grantResults.length>0 && grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED){
            // The next denied gate can post the local support notification.
        }
    }

    private void bind(){
        drawer=findViewById(R.id.drawerLayout);
        tvAppTitle=findViewById(R.id.tvAppTitle); tvHomeTitleView=findViewById(R.id.tvHomeTitle); tvInput=findViewById(R.id.tvInput); tvMode=findViewById(R.id.tvMode);
        tvProgress=findViewById(R.id.tvProgress); tvOutput=findViewById(R.id.tvOutput); tvStatus=findViewById(R.id.tvStatus);
        tvSignatureState=findViewById(R.id.tvSignatureState); tvPreviewInfo=findViewById(R.id.tvPreviewInfo); tvDrawerOutput=findViewById(R.id.tvDrawerOutput);
        tvSelectedCount=findViewById(R.id.tvSelectedCount); tvClass=findViewById(R.id.tvClass); tvOutputShort=findViewById(R.id.tvOutputShort);
        tvPreviewBadge=findViewById(R.id.tvPreviewBadge); tvFooter=findViewById(R.id.tvFooter);
        progress=findViewById(R.id.progress); signatureCard=findViewById(R.id.signatureCard); previewCard=findViewById(R.id.previewCard);
        previewImage=findViewById(R.id.previewImage); btnPreviewPlay=findViewById(R.id.btnPreviewPlay);
        btnTheme=findViewById(R.id.btnTheme); btnMenu=findViewById(R.id.btnMenu); btnCloseDrawer=findViewById(R.id.btnCloseDrawer);
        btnChooseFile=findViewById(R.id.btnChooseFile); btnDecrypt=findViewById(R.id.btnDecrypt);
        btnSave=findViewById(R.id.btnSave); btnClear=findViewById(R.id.btnClear); heroCard=findViewById(R.id.heroCard);
    }

    private void setupDrawer(){
        View d=findViewById(R.id.sideDrawer);
        d.post(()->{ int max=dp(360); int width=Math.min((int)(getResources().getDisplayMetrics().widthPixels*.86f),max); d.getLayoutParams().width=width; d.requestLayout(); });
        drawer.setDrawerElevation(dp(22));
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}

    private void wire(){
        btnMenu.setOnClickListener(v->drawer.openDrawer(Gravity.LEFT));
        btnCloseDrawer.setOnClickListener(v->drawer.closeDrawers());
        findViewById(R.id.navHome).setOnClickListener(v->drawer.closeDrawers());
        findViewById(R.id.navOutput).setOnClickListener(v->{drawer.closeDrawers();pickOutputFolder();});
        findViewById(R.id.navHistory).setOnClickListener(v->{drawer.closeDrawers();showHistory();});
        findViewById(R.id.navSignature).setOnClickListener(v->showSignatureOptions());
        findViewById(R.id.navColors).setOnClickListener(v->{drawer.closeDrawers();showColorPicker();});
        findViewById(R.id.navAbout).setOnClickListener(v->{drawer.closeDrawers();showInfo("About",aboutText());});
        findViewById(R.id.navPrivacy).setOnClickListener(v->{drawer.closeDrawers();showInfo("Privacy",privacyText());});
        findViewById(R.id.navTerms).setOnClickListener(v->{drawer.closeDrawers();showInfo("Terms & disclaimer",termsText());});

        btnChooseFile.setOnClickListener(v->pickFile());
        btnDecrypt.setOnClickListener(v->requestDecryptionAuthorization());
        btnSave.setOnClickListener(v->saveCurrentResult());
        btnClear.setOnClickListener(v->clearResult());
        btnPreviewPlay.setOnClickListener(v->openMediaViewer());
        previewImage.setOnClickListener(v->openMediaViewer());

        btnTheme.setOnClickListener(v->{
            boolean next=!prefs.getBoolean("dark",true);
            prefs.edit().putBoolean("dark",next).apply();
            applyUiMode(next);
            refreshThemeInPlace();
            refreshUi();
            applyAccent();
            animateTitle();
        });

        findViewById(R.id.infoSource).setOnClickListener(v->showInfo("Supported source","Select one or more encrypted MIUI .lsa or .lsav files. Only selected files are processed."));
        findViewById(R.id.infoDecrypt).setOnClickListener(v->showInfo("Decryption","Processing happens locally on the device. Single-file results remain in app-private temporary storage until you save or clear them. Batch mode writes directly to the selected output folder."));
        findViewById(R.id.infoPreview).setOnClickListener(v->showInfo("Result viewer","Images open in a pinch-to-zoom viewer with pan and double-tap reset. Videos open in the built-in player with play/pause and seek controls."));
        findViewById(R.id.tvSelectedCount).setOnClickListener(v->showInfo("Selected files","The count shows how many supported .lsa or .lsav files are currently selected."));
        findViewById(R.id.tvClass).setOnClickListener(v->showInfo("Media class","The detected class identifies whether the selected input is an image file or a video file."));
        findViewById(R.id.tvOutputShort).setOnClickListener(v->showInfo("Output location","The destination is used automatically for batch decryption. You can change it from the navigation menu."));
    }

    private void applyUiMode(boolean dark){
        Configuration c=new Configuration(getResources().getConfiguration());
        c.uiMode=(c.uiMode&~Configuration.UI_MODE_NIGHT_MASK)|(dark?Configuration.UI_MODE_NIGHT_YES:Configuration.UI_MODE_NIGHT_NO);
        getResources().updateConfiguration(c,getResources().getDisplayMetrics());
        getWindow().setStatusBarColor(getColor(R.color.bg));
        getWindow().setNavigationBarColor(getColor(R.color.bg));
        int flags=dark?0:(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    private void refreshThemeInPlace(){
        View root=findViewById(R.id.drawerLayout);
        if(root!=null)root.setBackgroundColor(getColor(R.color.bg));
        View top=findViewById(R.id.topActions);
        if(top!=null)top.setBackground(getDrawable(R.drawable.top_actions_bg));
        if(heroCard!=null)heroCard.setBackground(getDrawable(R.drawable.hero_card));
        View file=findViewById(R.id.fileCard); if(file!=null)file.setBackground(getDrawable(R.drawable.card_bg));
        if(signatureCard!=null)signatureCard.setBackground(getDrawable(R.drawable.card_bg));
        View action=findViewById(R.id.actionCard); if(action!=null)action.setBackground(getDrawable(R.drawable.card_bg));
        if(previewCard!=null)previewCard.setBackground(getDrawable(R.drawable.card_bg));
        View drawerView=findViewById(R.id.sideDrawer); if(drawerView!=null)drawerView.setBackground(getDrawable(R.drawable.drawer_bg));

        // Rebind the three metric cards because their XML drawables were resolved at inflation time.
        if(heroCard!=null && heroCard.getParent() instanceof LinearLayout){
            LinearLayout content=(LinearLayout)heroCard.getParent();
            if(content.getChildCount()>1 && content.getChildAt(1) instanceof LinearLayout){
                LinearLayout metrics=(LinearLayout)content.getChildAt(1);
                for(int i=0;i<metrics.getChildCount();i++){
                    View v=metrics.getChildAt(i);
                    if(v instanceof LinearLayout)v.setBackground(getDrawable(R.drawable.metric_card));
                }
            }
        }

        int primary=getColor(R.color.text_primary), secondary=getColor(R.color.text_secondary), muted=getColor(R.color.text_muted);
        int dText=getColor(R.color.drawer_text), dMuted=getColor(R.color.drawer_muted);
        int oldLightPrimary=Color.parseColor("#14212B"), oldDarkPrimary=Color.parseColor("#F2F6F8");
        int oldLightSecondary=Color.parseColor("#5C6B76"), oldDarkSecondary=Color.parseColor("#A9B7C2");
        int oldLightMuted=Color.parseColor("#84919A"), oldDarkMuted=Color.parseColor("#778895");
        int oldLightDrawerText=Color.parseColor("#14212B"), oldDarkDrawerText=Color.parseColor("#F2F6F8");
        int oldLightDrawerMuted=Color.parseColor("#687781"), oldDarkDrawerMuted=Color.parseColor("#91A0AB");
        recolorTextViews(root,oldLightPrimary,oldDarkPrimary,primary,oldLightSecondary,oldDarkSecondary,secondary,oldLightMuted,oldDarkMuted,muted,oldLightDrawerText,oldDarkDrawerText,dText,oldLightDrawerMuted,oldDarkDrawerMuted,dMuted);

        int[] questionIds={R.id.infoSource,R.id.infoDecrypt,R.id.infoPreview};
        for(int id:questionIds){TextView t=findViewById(id);if(t!=null){t.setBackground(getDrawable(R.drawable.question_circle));t.setTextColor(primary);}}
        TextView badge=findViewById(R.id.tvPreviewBadge);if(badge!=null){badge.setBackground(getDrawable(R.drawable.chip_bg));badge.setTextColor(primary);}
        ImageButton close=findViewById(R.id.btnCloseDrawer);if(close!=null)close.setBackground(getDrawable(R.drawable.icon_button_bg));
        int[] navIds={R.id.navHome,R.id.navOutput,R.id.navHistory,R.id.navSignature,R.id.navColors,R.id.navAbout,R.id.navPrivacy,R.id.navTerms};
        for(int id:navIds){View n=findViewById(id);if(n!=null)n.setBackground(getDrawable(R.drawable.nav_row_bg));}
    }

    private void recolorTextViews(View view,int lp,int dp,int np,int ls,int ds,int ns,int lm,int dm,int nm,int ldt,int ddt,int ndt,int ldm,int ddm,int ndm){
        if(view instanceof TextView){
            TextView t=(TextView)view; int c=t.getTextColors().getDefaultColor();
            if(c==lp||c==dp)t.setTextColor(np);
            else if(c==ls||c==ds)t.setTextColor(ns);
            else if(c==lm||c==dm)t.setTextColor(nm);
            else if(c==ldt||c==ddt)t.setTextColor(ndt);
            else if(c==ldm||c==ddm)t.setTextColor(ndm);
        }
        if(view instanceof ViewGroup){ViewGroup g=(ViewGroup)view;for(int i=0;i<g.getChildCount();i++)recolorTextViews(g.getChildAt(i),lp,dp,np,ls,ds,ns,lm,dm,nm,ldt,ddt,ndt,ldm,ddm,ndm);}
    }

    private void refreshUi(){
        boolean sig=prefs.getBoolean("signature",true);
        signatureCard.setVisibility(sig?View.VISIBLE:View.GONE);
        tvSignatureState.setText(sig?"ON":"OFF");
        String saved=prefs.getString("output_tree","");
        if(saved.isEmpty()){
            outputTreeUri=null; tvDrawerOutput.setText("Not selected"); tvOutputShort.setText("Not set");
        }else{
            try{outputTreeUri=Uri.parse(saved);String n=getTreeName(outputTreeUri);tvDrawerOutput.setText(n);tvOutputShort.setText(n);}
            catch(Exception e){outputTreeUri=null;tvDrawerOutput.setText("Not selected");tvOutputShort.setText("Not set");}
        }
        updateSelectionUi();
    }

    private void pickFile(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(i,REQ_FILE);
    }
    private void pickOutputFolder(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(i,REQ_OUTPUT_TREE);
    }
    private void openOutputFolder(){
        if(outputTreeUri==null){pickOutputFolder();return;}
        try{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
            i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,outputTreeUri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivity(i);
        }catch(Exception e){pickOutputFolder();}
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data); if(result!=RESULT_OK||data==null)return;
        try{
            Uri single=data.getData(); int take=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if(single!=null&&take!=0)getContentResolver().takePersistableUriPermission(single,take);
        }catch(Exception ignored){}
        if(req==REQ_FILE){
            selectedUris.clear();
            if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)addSelected(data.getClipData().getItemAt(i).getUri());}
            else if(data.getData()!=null)addSelected(data.getData());
            if(!selectedUris.isEmpty())selectInput(selectedUris.get(0));
        }else if(req==REQ_OUTPUT_TREE&&data.getData()!=null)outputFolderSelected(data.getData());
        else if(req==REQ_SAVE_AS&&data.getData()!=null)saveAsSelected(data.getData());
    }

    private void addSelected(Uri u){String n=FileNameUtil.getDisplayName(this,u);if(n!=null&&isSupported(n)&&!selectedUris.contains(u))selectedUris.add(u);}
    private boolean isSupported(String n){String s=n==null?"":n.toLowerCase(Locale.US);return s.endsWith(".lsa")||s.endsWith(".lsav");}
    private void selectInput(Uri uri){
        inputUri=uri; inputName=FileNameUtil.getDisplayName(this,uri); if(inputName==null)inputName="selected_file";
        boolean video=inputName.toLowerCase(Locale.US).endsWith(".lsav");
        tvInput.setText(selectedUris.size()>1?inputName+"  +"+(selectedUris.size()-1)+" more":inputName);
        tvMode.setText(video?".lsav  •  video":".lsa  •  image");
        tvClass.setText(video?"VIDEO":"IMAGE"); tvStatus.setText("Ready to decrypt"); tvOutput.setText("Ready");
        btnDecrypt.setEnabled(true); clearPreviewOnly(); updateSelectionUi();
    }
    private void updateSelectionUi(){
        tvSelectedCount.setText(String.valueOf(selectedUris.size()));
        if(selectedUris.isEmpty()){
            tvClass.setText("—"); tvInput.setText("No encrypted media selected"); tvMode.setText("Choose one or more .lsa / .lsav files"); btnDecrypt.setEnabled(false);
        }
    }

    private void requestDecryptionAuthorization(){
        if(integrityLocked || !IntegrityGuard.isOfficialBuild(this)){
            integrityLocked = true;
            btnDecrypt.setEnabled(false);
            showInfo("Modification detected", "This application appears to have been modified or re-signed. Decryption has been permanently disabled for this installation. Please use the official application.");
            return;
        }
        if(selectedUris.isEmpty()){
            showInfo("No file selected", "Choose one or more encrypted .lsa / .lsav files first.");
            return;
        }
        if (rewardedAdGate == null) {
            btnDecrypt.setEnabled(true);
            showInfo("Support ad", "The ad service is still starting. Please wait a moment and try again.");
            return;
        }
        btnDecrypt.setEnabled(false);
        tvStatus.setText("Waiting for support ad");
        tvOutput.setText("Complete the rewarded ad to unlock decryption.");
        rewardedAdGate.show(new RewardedAdGate.Callback(){
            @Override public void onAuthorized(){
                if(integrityLocked || !IntegrityGuard.isOfficialBuild(MainActivity.this)){
                    integrityLocked=true;
                    btnDecrypt.setEnabled(false);
                    showInfo("Modification detected", "Decryption has been disabled because application integrity could not be verified.");
                    return;
                }
                startDecryption();
            }
            @Override public void onDenied(String message){
                main.post(()->{
                    btnDecrypt.setEnabled(!selectedUris.isEmpty());
                    tvStatus.setText("Decryption locked");
                    tvOutput.setText("Rewarded ad required");
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7001);
                    } else {
                        SupportNotification.notifyUser(MainActivity.this);
                    }
                    showInfo("Decryption locked", message);
                });
            }
        });
    }

    private void startDecryption(){
        if(selectedUris.size()>1){
            if(outputTreeUri==null){showInfo("Output folder required","Batch mode saves each decrypted file automatically. Choose an output folder first.");return;}
            startBatchDecryption();
        }else if(inputUri!=null)startSingleDecryption();
    }
    private void startSingleDecryption(){
        final Uri source=inputUri; final String name=inputName; setBusy(true); clearPreviewOnly(); progress.setProgress(0); tvProgress.setText("0%"); tvStatus.setText("Decrypting"); tvOutput.setText("Processing locally…");
        pool.execute(()->{
            try{
                File f=File.createTempFile("miui_decrypted_",".tmp",getCacheDir());
                boolean video=name.toLowerCase(Locale.US).endsWith(".lsav"); long total=getSize(source);
                try(InputStream in=new BufferedInputStream(getContentResolver().openInputStream(source));OutputStream out=new BufferedOutputStream(new FileOutputStream(f))){
                    if(in==null)throw new IOException("Cannot open selected file.");
                    DecryptEngine.decrypt(in,out,total,video,(p,t)->main.post(()->setProgress(p,t)));
                }
                boolean sig=prefs.getBoolean("signature",true); FormatDetector.Result d=sig?FormatDetector.detect(f,video):FormatDetector.fallbackForClass(video);
                if(tempFile!=null)tempFile.delete(); tempFile=f; detected=d;
                main.post(()->{progress.setProgress(100);tvProgress.setText("100%");tvStatus.setText("Decryption complete");tvOutput.setText("Result is temporary until you save it.");showPreview();setBusy(false);logHistoryEvent("Decrypted",name);});
            }catch(Exception e){main.post(()->{tvStatus.setText("Decryption failed");tvOutput.setText(safeMsg(e));setBusy(false);});}
        });
    }
    private void startBatchDecryption(){
        final ArrayList<Uri> batch=new ArrayList<>(selectedUris); setBusy(true); progress.setProgress(0); tvProgress.setText("0%"); tvStatus.setText("Batch decrypting");
        pool.execute(()->{
            int ok=0; ArrayList<String> failed=new ArrayList<>();
            for(int i=0;i<batch.size();i++){
                final int index=i; Uri u=batch.get(i); String name=FileNameUtil.getDisplayName(this,u); if(name==null)name="file_"+i;
                try{
                    boolean video=name.toLowerCase(Locale.US).endsWith(".lsav"); long total=getSize(u); File f=File.createTempFile("miui_batch_",".tmp",getCacheDir());
                    try(InputStream in=new BufferedInputStream(getContentResolver().openInputStream(u));OutputStream out=new BufferedOutputStream(new FileOutputStream(f))){
                        if(in==null)throw new IOException("Cannot open file");
                        DecryptEngine.decrypt(in,out,total,video,(p,t)->{int base=index*100/batch.size();int span=100/batch.size();main.post(()->setProgress(base+(t>0?(int)(p*span/t):0),100));});
                    }
                    boolean sig=prefs.getBoolean("signature",true); FormatDetector.Result d=sig?FormatDetector.detect(f,video):FormatDetector.fallbackForClass(video); saveBatchFile(f,d,name); f.delete(); ok++; logHistoryEvent("Batch saved",name);
                }catch(Exception e){failed.add(name+" — "+safeMsg(e));}
            }
            final int good=ok; main.post(()->{progress.setProgress(100);tvProgress.setText("100%");setBusy(false);tvStatus.setText("Batch complete");tvOutput.setText(good+" of "+batch.size()+" files saved");selectedUris.clear();inputUri=null;updateSelectionUi();if(failed.isEmpty())showInfo("Batch complete",good+" file(s) decrypted and saved successfully.");else showInfo("Batch finished",good+" saved.\n\nFailed:\n"+join(failed));});
        });
    }
    private void saveBatchFile(File f,FormatDetector.Result d,String name)throws Exception{
        DocumentFile folder=DocumentFile.fromTreeUri(this,outputTreeUri); if(folder==null||!folder.isDirectory()||!folder.canWrite())throw new IOException("Output folder is unavailable or not writable.");
        String out=decryptedName(name,d); DocumentFile target=folder.createFile(d.mime,out); if(target==null)throw new IOException("Could not create output file.");
        try(InputStream in=new BufferedInputStream(new FileInputStream(f));OutputStream outStream=new BufferedOutputStream(getContentResolver().openOutputStream(target.getUri(),"w"))){if(outStream==null)throw new IOException("Cannot open output file.");byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1)outStream.write(b,0,n);outStream.flush();}
    }
    private void setProgress(long p,long t){int q=t>0?(int)Math.min(100,p*100L/t):0;progress.setProgress(q);tvProgress.setText(q+"%");}

    private void showPreview(){
        previewCard.setVisibility(View.VISIBLE); previewImage.setImageDrawable(null); btnPreviewPlay.setVisibility(View.GONE);
        if(detected==null||tempFile==null)return;
        if(detected.mime.startsWith("image/")){
            Bitmap b=decodeSampled(tempFile.getAbsolutePath(),previewImage.getWidth(),previewImage.getHeight());
            if(b!=null){previewImage.setImageBitmap(b);tvPreviewInfo.setText(detected.label+"  •  "+b.getWidth()+" × "+b.getHeight());}
            tvPreviewBadge.setText("IMAGE  •  TAP TO ZOOM");
        }else if(detected.mime.startsWith("video/")){
            MediaMetadataRetriever r=new MediaMetadataRetriever();
            try{r.setDataSource(tempFile.getAbsolutePath());Bitmap frame=r.getFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);if(frame!=null)previewImage.setImageBitmap(frame);String dur=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);tvPreviewInfo.setText(detected.label+(dur==null?"":"  •  "+formatDuration(dur)));}
            catch(Exception e){tvPreviewInfo.setText(detected.label+"  •  preview unavailable");}
            finally{try{r.release();}catch(Exception ignored){}}
            btnPreviewPlay.setVisibility(View.VISIBLE); tvPreviewBadge.setText("VIDEO  •  TAP TO PLAY");
        }else tvPreviewInfo.setText(detected.label+"  •  preview unavailable");
    }
    private Bitmap decodeSampled(String path,int reqW,int reqH){
        try{BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeFile(path,o);int w=o.outWidth,h=o.outHeight;if(w<=0||h<=0)return null;int sample=1;while(reqW>0&&reqH>0&&(w/sample>reqW*2||h/sample>reqH*2))sample*=2;o.inSampleSize=sample;o.inJustDecodeBounds=false;return BitmapFactory.decodeFile(path,o);}catch(Exception e){return null;}
    }
    private void clearPreviewOnly(){previewCard.setVisibility(View.GONE);previewImage.setImageDrawable(null);btnPreviewPlay.setVisibility(View.GONE);}
    private void clearResult(){if(tempFile!=null)tempFile.delete();tempFile=null;detected=null;clearPreviewOnly();progress.setProgress(0);tvProgress.setText("0%");tvStatus.setText(inputUri==null?"Choose encrypted media to begin":"Ready to decrypt");tvOutput.setText("Ready");btnSave.setEnabled(false);}
    private void openMediaViewer(){if(tempFile==null||!tempFile.exists()||detected==null)return;if(detected.mime.startsWith("image/"))showImageViewer(Uri.fromFile(tempFile));else if(detected.mime.startsWith("video/"))showVideoPlayer(Uri.fromFile(tempFile));}

    private void showImageViewer(Uri uri){
        final Dialog dialog=new Dialog(this,android.R.style.Theme_Black_NoTitleBar_Fullscreen); FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        ImageView image=new ImageView(this); image.setScaleType(ImageView.ScaleType.FIT_CENTER); root.addView(image,new FrameLayout.LayoutParams(-1,-1));
        TextView title=overlayText("Image  •  pinch to zoom",14);title.setPadding(dp(18),dp(16),dp(18),dp(16));root.addView(title,new FrameLayout.LayoutParams(-2,dp(60),Gravity.TOP|Gravity.START));
        Button close=overlayButton("Close");FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(88),dp(50),Gravity.TOP|Gravity.END);cp.setMargins(0,dp(10),dp(10),0);root.addView(close,cp);
        close.setOnClickListener(v->dialog.dismiss());dialog.setContentView(root);dialog.show();
        Bitmap b=decodeUriBitmap(uri); if(b!=null){image.setImageBitmap(b);enableZoom(image);}
    }

    private Bitmap decodeUriBitmap(Uri uri){
        try{
            BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;
            if("file".equals(uri.getScheme()))BitmapFactory.decodeFile(uri.getPath(),o);else try(ParcelFileDescriptor pfd=getContentResolver().openFileDescriptor(uri,"r")){if(pfd==null)return null;BitmapFactory.decodeFileDescriptor(pfd.getFileDescriptor(),null,o);}
            int w=o.outWidth,h=o.outHeight;if(w<=0||h<=0)return null;int reqW=getResources().getDisplayMetrics().widthPixels,reqH=getResources().getDisplayMetrics().heightPixels;int sample=1;while(w/sample>reqW*2||h/sample>reqH*2)sample*=2;o.inSampleSize=sample;o.inJustDecodeBounds=false;
            if("file".equals(uri.getScheme()))return BitmapFactory.decodeFile(uri.getPath(),o);try(ParcelFileDescriptor pfd=getContentResolver().openFileDescriptor(uri,"r")){if(pfd==null)return null;return BitmapFactory.decodeFileDescriptor(pfd.getFileDescriptor(),null,o);}
        }catch(Exception e){return null;}
    }

    private void enableZoom(ImageView image){
        final Matrix base=new Matrix();
        final Matrix matrix=new Matrix();
        final float[] zoomScale={1f};
        final ScaleGestureDetector detector=new ScaleGestureDetector(this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override public boolean onScale(ScaleGestureDetector d){
                float next=Math.max(1f,Math.min(7f,zoomScale[0]*d.getScaleFactor()));
                float factor=next/zoomScale[0]; matrix.postScale(factor,factor,d.getFocusX(),d.getFocusY()); zoomScale[0]=next; image.setImageMatrix(matrix); return true;
            }
        });
        image.setScaleType(ImageView.ScaleType.MATRIX);
        image.post(()->{
            Drawable drawable=image.getDrawable();
            if(drawable==null)return;
            float vw=image.getWidth(),vh=image.getHeight(),dw=drawable.getIntrinsicWidth(),dh=drawable.getIntrinsicHeight();
            if(dw<=0||dh<=0)return;
            float fit=Math.min(vw/dw,vh/dh),dx=(vw-dw*fit)/2f,dy=(vh-dh*fit)/2f;
            base.setScale(fit,fit);base.postTranslate(dx,dy);matrix.set(base);image.setImageMatrix(matrix);
        });
        final GestureDetector taps=new GestureDetector(this,new GestureDetector.SimpleOnGestureListener(){
            @Override public boolean onDown(MotionEvent e){return true;}
            @Override public boolean onDoubleTap(MotionEvent e){zoomScale[0]=1f;matrix.set(base);image.setImageMatrix(matrix);return true;}
        });
        image.setOnTouchListener(new View.OnTouchListener(){float lastX,lastY;boolean dragging;
            public boolean onTouch(View v,MotionEvent e){taps.onTouchEvent(e);detector.onTouchEvent(e);switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:lastX=e.getX();lastY=e.getY();dragging=true;return true;
                case MotionEvent.ACTION_MOVE:if(!detector.isInProgress()&&dragging&&zoomScale[0]>1f){float dx=e.getX()-lastX,dy=e.getY()-lastY;matrix.postTranslate(dx,dy);image.setImageMatrix(matrix);lastX=e.getX();lastY=e.getY();}return true;
                case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:dragging=false;return true;
                default:return true;
            }}
        });
    }

    private void showVideoPlayer(Uri uri){
        final Dialog dialog=new Dialog(this,android.R.style.Theme_Black_NoTitleBar_Fullscreen);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.BLACK);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);TextView title=overlayText("Video",15);bar.addView(title,new LinearLayout.LayoutParams(0,dp(52),1));Button close=overlayButton("Close");bar.addView(close,new LinearLayout.LayoutParams(dp(88),dp(50)));root.addView(bar);
        VideoView video=new VideoView(this);root.addView(video,new LinearLayout.LayoutParams(-1,0,1));LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER_VERTICAL);Button play=overlayButton("Play");SeekBar seek=new SeekBar(this);TextView time=overlayText("0:00",11);controls.addView(play,new LinearLayout.LayoutParams(dp(82),dp(50)));controls.addView(seek,new LinearLayout.LayoutParams(0,dp(50),1));controls.addView(time,new LinearLayout.LayoutParams(dp(55),dp(50)));root.addView(controls);dialog.setContentView(root);dialog.show();
        close.setOnClickListener(v->dialog.dismiss());video.setVideoURI(uri);Handler h=new Handler(Looper.getMainLooper());Runnable tick=new Runnable(){public void run(){if(video.getDuration()>0){seek.setMax(video.getDuration());seek.setProgress(video.getCurrentPosition());time.setText(formatDuration(String.valueOf(video.getCurrentPosition())));}h.postDelayed(this,500);}};
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){if(f)video.seekTo(p);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
        video.setOnPreparedListener(mp->{video.start();play.setText("Pause");h.post(tick);});video.setOnCompletionListener(mp->play.setText("Play"));play.setOnClickListener(v->{if(video.isPlaying()){video.pause();play.setText("Play");}else{video.start();play.setText("Pause");}});dialog.setOnDismissListener(d->h.removeCallbacksAndMessages(null));
    }

    private TextView overlayText(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);t.setTypeface(null,Typeface.BOLD);return t;}
    private Button overlayButton(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundColor(0x66333333);return b;}

    private void saveCurrentResult(){
        if(tempFile==null||!tempFile.exists()||detected==null){showInfo("Nothing to save","Decrypt a file first.");return;}
        if(outputTreeUri!=null)saveIntoFolder();else{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(detected.mime);i.putExtra(Intent.EXTRA_TITLE,decryptedName(inputName,detected));i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,REQ_SAVE_AS);}
    }
    private void saveIntoFolder(){pool.execute(()->{try{DocumentFile folder=DocumentFile.fromTreeUri(this,outputTreeUri);if(folder==null||!folder.exists()||!folder.isDirectory()||!folder.canWrite())throw new IOException("Output folder is unavailable or not writable.");DocumentFile target=folder.createFile(detected.mime,decryptedName(inputName,detected));if(target==null)throw new IOException("Android could not create the output file.");copyToUri(target.getUri());}catch(Exception e){main.post(()->showInfo("Save failed",safeMsg(e)));}});}
    private void copyToUri(Uri destination)throws Exception{try(InputStream in=new BufferedInputStream(new FileInputStream(tempFile));OutputStream out=new BufferedOutputStream(getContentResolver().openOutputStream(destination,"w"))){if(out==null)throw new IOException("Cannot open output file.");byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1)out.write(b,0,n);out.flush();}String name=decryptedName(inputName,detected);main.post(()->{tvStatus.setText("Saved");tvOutput.setText("Saved: "+name);btnSave.setEnabled(false);logHistoryEvent("Saved",name);Toast.makeText(this,"Saved successfully",Toast.LENGTH_SHORT).show();});}
    private void saveAsSelected(Uri destination){pool.execute(()->{try{copyToUri(destination);}catch(Exception e){main.post(()->showInfo("Save failed",safeMsg(e)));}});}
    private void outputFolderSelected(Uri tree){try{DocumentFile folder=DocumentFile.fromTreeUri(this,tree);if(folder==null||!folder.isDirectory())throw new IOException("Invalid folder.");outputTreeUri=tree;prefs.edit().putString("output_tree",tree.toString()).apply();String n=getTreeName(tree);tvDrawerOutput.setText(n);tvOutputShort.setText(n);Toast.makeText(this,"Output folder selected",Toast.LENGTH_SHORT).show();}catch(Exception e){showInfo("Folder unavailable",safeMsg(e));}}
    private String getTreeName(Uri tree){try{String id=DocumentsContract.getTreeDocumentId(tree);Uri doc=DocumentsContract.buildDocumentUriUsingTree(tree,id);String n=FileNameUtil.getDisplayName(this,doc);if(n!=null&&!n.isEmpty())return n;}catch(Exception ignored){}return "Selected folder";}
    private long getSize(Uri u){try(Cursor c=getContentResolver().query(u,new String[]{OpenableColumns.SIZE},null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.SIZE);if(i>=0&&!c.isNull(i))return c.getLong(i);}}catch(Exception ignored){}return -1;}
    private void setBusy(boolean b){btnChooseFile.setEnabled(!b);btnDecrypt.setEnabled(!b&&!selectedUris.isEmpty());btnSave.setEnabled(!b&&tempFile!=null&&tempFile.exists());btnClear.setEnabled(!b);}

    private void showSignatureOptions(){
        final boolean enabledNow = prefs.getBoolean("signature", true);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), 0, dp(4), 0);

        TextView title = new TextView(this);
        title.setText("Signature detection");
        title.setTextColor(getColor(R.color.text_primary));
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        box.addView(title);

        TextView line = new TextView(this);
        line.setText("Verify the actual decrypted container instead of trusting only the .lsa / .lsav extension.");
        line.setTextColor(getColor(R.color.text_secondary));
        line.setTextSize(13);
        line.setLineSpacing(dp(2), 1f);
        line.setPadding(0, dp(10), 0, dp(8));
        box.addView(line);

        CheckBox check = new CheckBox(this);
        check.setText("Enable signature detection");
        check.setTextColor(getColor(R.color.text_primary));
        check.setTextSize(14);
        check.setChecked(enabledNow);
        check.setButtonTintList(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{accentColor, getColor(R.color.text_muted)}));
        box.addView(check);

        TextView protection = new TextView(this);
        protection.setText("App integrity protection is separate and always enforced before decryption.");
        protection.setTextColor(getColor(R.color.text_muted));
        protection.setTextSize(11);
        protection.setPadding(0, dp(4), 0, dp(4));
        box.addView(protection);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        Button cancel = new Button(this);
        cancel.setText("Cancel");
        cancel.setAllCaps(false);
        cancel.setTextColor(accentColor);
        Button save = new Button(this);
        save.setText("Save");
        save.setAllCaps(false);
        save.setTextColor(accentColor);
        actions.addView(cancel, new LinearLayout.LayoutParams(dp(100), dp(52)));
        actions.addView(save, new LinearLayout.LayoutParams(dp(90), dp(52)));
        box.addView(actions);

        final Dialog dialog = new Dialog(this);
        dialog.setContentView(box);
        cancel.setOnClickListener(v -> dialog.dismiss());
        save.setOnClickListener(v -> {
            boolean value = check.isChecked();
            prefs.edit().putBoolean("signature", value).apply();
            refreshUi();
            dialog.dismiss();
            Toast.makeText(this, value ? "Signature detection enabled" : "Signature detection disabled", Toast.LENGTH_SHORT).show();
        });
        dialog.show();
        Window w = dialog.getWindow();
        if(w != null){
            w.setBackgroundDrawableResource(R.drawable.dialog_bg);
            w.setDimAmount(.5f);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.width = Math.min((int)(getResources().getDisplayMetrics().widthPixels * .9f), dp(390));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
    }

    private void showColorPicker(){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4),dp(2),dp(4),0);

        TextView hint=new TextView(this);
        hint.setText("Choose a preset accent.");
        hint.setTextColor(getColor(R.color.text_secondary));
        hint.setTextSize(12);
        hint.setPadding(0,0,0,dp(14));
        box.addView(hint);

        int[] colors={Color.parseColor("#5C8DFF"),Color.parseColor("#7B4DFF"),Color.parseColor("#00A6A6"),Color.parseColor("#E04F8A"),Color.parseColor("#F28C28"),Color.parseColor("#19A974"),Color.parseColor("#00A8FF"),Color.parseColor("#FF5C8A"),Color.parseColor("#8B5CF6"),Color.parseColor("#14B8A6"),Color.parseColor("#F59E0B"),Color.parseColor("#EF4444")};
        for(int rowIndex=0;rowIndex<3;rowIndex++){
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER);
            for(int col=0;col<4;col++){
                int c=colors[rowIndex*4+col];
                FrameLayout swatch=new FrameLayout(this);
                swatch.setPadding(dp(3),dp(3),dp(3),dp(3));
                ImageView dot=new ImageView(this);
                dot.setBackground(roundFill(c,dp(16)));
                swatch.addView(dot,new FrameLayout.LayoutParams(dp(44),dp(44)));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(50),dp(50));
                lp.setMargins(dp(5),dp(3),dp(5),dp(3));
                row.addView(swatch,lp);
                swatch.setOnClickListener(v->{setAccent(c); Toast.makeText(this,"Applied",Toast.LENGTH_SHORT).show();});
            }
            box.addView(row);
        }

        TextView current=new TextView(this);
        current.setText("accent applies instantly.");
        current.setTextColor(getColor(R.color.text_muted));
        current.setTextSize(11);
        current.setGravity(Gravity.CENTER);
        current.setPadding(0,dp(10),0,0);
        box.addView(current);

        final Dialog dialog=new Dialog(this);
        dialog.setContentView(box);
        dialog.show();
        Window w=dialog.getWindow();
        if(w!=null){w.setBackgroundDrawableResource(R.drawable.dialog_bg);w.setDimAmount(.48f);WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min((int)(getResources().getDisplayMetrics().widthPixels*.9f),dp(390));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;w.setAttributes(lp);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}
    }

    private void setAccent(int color){accentColor=color;prefs.edit().putInt("accent",color).apply();applyAccent();}
    private void applyAccent(){
        try{accentColor=prefs.getInt("accent",Color.parseColor(DEFAULT_ACCENT));}catch(Exception e){accentColor=Color.parseColor(DEFAULT_ACCENT);}
        int dark=blend(accentColor,Color.BLACK,.62f);
        heroCard.setBackground(gradient(accentColor,dark));
        int[] accentViews={R.id.tvSelectedCount,R.id.tvClass,R.id.tvOutputShort,R.id.tvProgress};for(int id:accentViews)((TextView)findViewById(id)).setTextColor(accentColor);
        progress.setProgressTintList(ColorStateList.valueOf(accentColor));
        boolean darkTheme=prefs.getBoolean("dark",true);
        if(btnTheme!=null){btnTheme.setImageResource(darkTheme?R.drawable.ic_sun:R.drawable.ic_moon);btnTheme.setColorFilter(accentColor,PorterDuff.Mode.SRC_IN);}
        if(btnMenu!=null)btnMenu.setColorFilter(accentColor,PorterDuff.Mode.SRC_IN);
        int secondaryFill=darkTheme?blend(accentColor,Color.BLACK,.72f):blend(accentColor,Color.WHITE,.88f);
        int foreground=contrastText(accentColor);
        Button[] primaryButtons={btnChooseFile,btnDecrypt,btnSave};
        for(Button b:primaryButtons){if(b!=null){b.setBackground(roundFill(accentColor,dp(15)));b.setTextColor(foreground);}}
        if(btnPreviewPlay!=null){btnPreviewPlay.setBackground(roundFill(accentColor,dp(15)));btnPreviewPlay.setColorFilter(foreground,PorterDuff.Mode.SRC_IN);}
        View[] secondary={btnClear};for(View b:secondary)if(b!=null)b.setBackground(roundStroke(secondaryFill,accentColor,dp(15)));
        ImageView[] icons={btnMenu,btnCloseDrawer};for(ImageView v:icons)if(v!=null)v.setColorFilter(accentColor,PorterDuff.Mode.SRC_IN);
    }
    private GradientDrawable roundFill(int c,int radius){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(radius);return g;}
    private GradientDrawable roundStroke(int fill,int stroke,int radius){GradientDrawable g=roundFill(fill,radius);g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable gradient(int start,int end){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{start,end});g.setCornerRadius(dp(26));g.setStroke(dp(1),blend(accentColor,Color.WHITE,.55f));return g;}
    private int blend(int a,int b,float amount){return Color.rgb((int)(Color.red(a)*(1-amount)+Color.red(b)*amount),(int)(Color.green(a)*(1-amount)+Color.green(b)*amount),(int)(Color.blue(a)*(1-amount)+Color.blue(b)*amount));}
    private int contrastText(int c){double y=(0.2126*Color.red(c)+0.7152*Color.green(c)+0.0722*Color.blue(c))/255.0;return y>0.62?Color.BLACK:Color.WHITE;}

    private void animateTitle(){
        final String target="MIUI Gallery Decryptor";
        main.removeCallbacksAndMessages("typing");
        tvAppTitle.setText(target);
        tvHomeTitleView.setVisibility(View.VISIBLE);
        tvHomeTitleView.setAlpha(1f);
        tvHomeTitleView.setContentDescription(target);
        if(tvHomeTitleView!=null){
            TextView t=tvHomeTitleView; t.setText("");
            final int[] i={0};
            Runnable r=new Runnable(){public void run(){if(i[0]<=target.length()){t.setText(target.substring(0,i[0]++));main.postAtTime(this,"typing",System.currentTimeMillis()+42);}}};
            main.postAtTime(r,"typing",System.currentTimeMillis());
        }
    }
    private void restartApp(){
        try{Intent intent=getPackageManager().getLaunchIntentForPackage(getPackageName());if(intent==null){recreate();return;}intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(intent);finish();overridePendingTransition(0,0);}catch(Exception e){recreate();}
    }

    private void showHistory(){JSONArray a=readHistory();if(a.length()==0){showInfo("Activity history","No activity yet.");return;}StringBuilder s=new StringBuilder();for(int i=a.length()-1;i>=0;i--){try{s.append(a.getString(i)).append("\n\n");}catch(Exception ignored){}}new AlertDialog.Builder(this).setTitle("Activity history").setMessage(s.toString()).setNeutralButton("Clear",(d,w)->prefs.edit().remove("history").apply()).setPositiveButton("Done",null).show();}
    private JSONArray readHistory(){try{return new JSONArray(prefs.getString("history","[]"));}catch(Exception e){return new JSONArray();}}
    private void logHistoryEvent(String action,String value){JSONArray a=readHistory(),n=new JSONArray();for(int i=Math.max(0,a.length()-49);i<a.length();i++)try{n.put(a.getString(i));}catch(Exception ignored){}n.put(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date())+" • "+action+" • "+value);prefs.edit().putString("history",n.toString()).apply();}
    private String decryptedName(String base,FormatDetector.Result d){if(base==null)base="decrypted_file";int dot=base.lastIndexOf('.');if(dot>0)base=base.substring(0,dot);return "decrypted_"+base+(d==null?".bin":d.extension);}
    private String formatDuration(String ms){try{long v=Long.parseLong(ms);return String.format(Locale.US,"%d:%02d",v/60000,(v/1000)%60);}catch(Exception e){return "0:00";}}
    private String join(ArrayList<String> a){StringBuilder s=new StringBuilder();for(String x:a)s.append("• ").append(x).append("\n");return s.toString();}
    private void showInfo(String t,String m){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),0,dp(4),0);
        TextView title=new TextView(this);title.setText(t);title.setTextColor(getColor(R.color.text_primary));title.setTextSize(20);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);box.addView(title);
        View line=new View(this);line.setBackgroundColor(accentColor);LinearLayout.LayoutParams lineLp=new LinearLayout.LayoutParams(dp(42),dp(3));lineLp.setMargins(0,dp(10),0,dp(12));box.addView(line,lineLp);
        TextView msg=new TextView(this);msg.setText(m);msg.setTextColor(getColor(R.color.text_secondary));msg.setTextSize(13);msg.setLineSpacing(dp(2),1f);box.addView(msg);
        Button ok=new Button(this);ok.setText("Done");ok.setAllCaps(false);ok.setTextColor(android.graphics.Color.WHITE);ok.setTypeface(Typeface.DEFAULT,Typeface.BOLD);ok.setBackground(roundFill(accentColor,dp(16)));LinearLayout.LayoutParams okLp=new LinearLayout.LayoutParams(-1,dp(48));okLp.setMargins(0,dp(18),0,0);box.addView(ok,okLp);
        final Dialog dialog=new Dialog(this);dialog.setContentView(box);ok.setOnClickListener(v->dialog.dismiss());dialog.show();Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(R.drawable.dialog_bg);w.setDimAmount(.5f);WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min((int)(getResources().getDisplayMetrics().widthPixels*.9f),dp(390));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;w.setAttributes(lp);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}
    }
    private String safeMsg(Exception e){String m=e.getMessage();return m==null?e.getClass().getSimpleName():m;}
    private String aboutText(){return "MIUI Gallery Decryptor\n\nAn offline utility for authorized recovery, backup and personal data restoration.\n\nContact\nEmail: animecruze@freeinternet.io\nTelegram: mr_exit2\nInstagram: rumahiyadav\n\nMade With ❤️‍🩹 By MahiYadav";}
    private String privacyText(){return "Privacy\n\n• Selected files and folders are accessed only through Android's file picker.\n• Decryption runs locally on the device.\n• Single-file decrypted results are stored temporarily in the app cache until saved or cleared.\n• Saved output remains in the folder you select.\n• Activity history is stored locally in app preferences and can be cleared from the History screen.\n\nDo not select files you are not authorized to access.";}
    private String termsText(){return "Terms & disclaimer\n\nThis application is provided for authorized recovery, backup, migration and educational use. You are responsible for having the right to access and decrypt the files you select.\n\nThe application does not guarantee successful recovery for every encrypted file, damaged file or unsupported container. Format detection is best-effort and should be verified before relying on recovered media.\n\nNo warranty is made regarding data integrity. Keep an original backup before processing important data.";}
    @Override protected void onDestroy(){main.removeCallbacksAndMessages(null);if(tempFile!=null)tempFile.delete();pool.shutdownNow();super.onDestroy();}
}
