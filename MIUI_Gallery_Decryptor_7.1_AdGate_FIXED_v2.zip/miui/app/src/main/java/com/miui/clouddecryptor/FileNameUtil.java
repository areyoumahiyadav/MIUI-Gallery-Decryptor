package com.miui.clouddecryptor;
import android.content.Context; import android.database.Cursor; import android.net.Uri; import android.provider.OpenableColumns;
public final class FileNameUtil {
 public static String getDisplayName(Context c, Uri u) {
  try(Cursor x=c.getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
   if(x!=null&&x.moveToFirst()){int i=x.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return x.getString(i);}
  }catch(Exception ignored){} return null;
 }
 private FileNameUtil(){}
}