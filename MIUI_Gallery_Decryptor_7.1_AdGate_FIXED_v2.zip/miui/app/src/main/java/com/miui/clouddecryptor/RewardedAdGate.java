package com.miui.clouddecryptor;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

/**
 * Mandatory rewarded-ad gate.
 * Decryption is authorized only after the Google Mobile Ads reward callback.
 * Loading is asynchronous, so show() waits for the ad instead of immediately
 * treating a still-loading ad as unavailable.
 */
public final class RewardedAdGate {
    public interface Callback { void onAuthorized(); void onDenied(String message); }

    private static final String AD_UNIT_ID = BuildConfig.REWARDED_AD_UNIT_ID;
    private static final long LOAD_TIMEOUT_MS = 15000L;

    private final Activity activity;
    private final Handler main = new Handler(Looper.getMainLooper());
    private RewardedAd rewardedAd;
    private boolean loading;
    private Callback pendingCallback;
    private Runnable timeoutRunnable;

    public RewardedAdGate(Activity activity) {
        this.activity = activity;
        load();
    }

    public void load() {
        if (loading || rewardedAd != null) return;
        loading = true;
        RewardedAd.load(activity, AD_UNIT_ID, new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override public void onAdLoaded(RewardedAd ad) {
                        loading = false;
                        rewardedAd = ad;
                        if (pendingCallback != null) {
                            Callback cb = pendingCallback;
                            pendingCallback = null;
                            cancelTimeout();
                            showLoadedAd(ad, cb);
                        }
                    }

                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        loading = false;
                        rewardedAd = null;
                        if (pendingCallback != null) {
                            Callback cb = pendingCallback;
                            pendingCallback = null;
                            cancelTimeout();
                            cb.onDenied("The support ad could not be loaded. Please check your internet connection or disable the network-level ad blocker, then try again.");
                        }
                    }
                });
    }

    public void show(Callback callback) {
        if (!IntegrityGuard.isOfficialBuild(activity)) {
            callback.onDenied("Modification detected. Decryption has been disabled. Please use the official application.");
            return;
        }
        if (rewardedAd != null) {
            RewardedAd ad = rewardedAd;
            rewardedAd = null;
            showLoadedAd(ad, callback);
            return;
        }

        if (pendingCallback != null) {
            callback.onDenied("A support ad request is already in progress. Please wait a moment and try again.");
            return;
        }

        pendingCallback = callback;
        if (!loading) load();
        timeoutRunnable = () -> {
            if (pendingCallback != null) {
                Callback cb = pendingCallback;
                pendingCallback = null;
                cb.onDenied("A support ad is unavailable right now. Please check your internet connection or ad-blocking settings and try again.");
            }
        };
        main.postDelayed(timeoutRunnable, LOAD_TIMEOUT_MS);
    }

    private void showLoadedAd(RewardedAd ad, Callback callback) {
        final boolean[] rewarded = {false};
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() {
                if (!rewarded[0]) callback.onDenied("The support ad was closed before the reward was granted, so decryption was not started.");
                load();
            }

            @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                callback.onDenied("The support ad could not be shown, so decryption was not started.");
                load();
            }
        });
        ad.show(activity, rewardItem -> {
            rewarded[0] = true;
            callback.onAuthorized();
        });
    }

    private void cancelTimeout() {
        if (timeoutRunnable != null) {
            main.removeCallbacks(timeoutRunnable);
            timeoutRunnable = null;
        }
    }
}
