package com.miui.clouddecryptor;

import java.io.*;
import java.nio.charset.StandardCharsets;

public final class FormatDetector {
    public static final class Result {
        public final String extension;
        public final String label;
        public final String mime;
        Result(String e, String l, String m) { extension=e; label=l; mime=m; }
    }

    public static Result detect(File f, boolean videoClass) throws IOException {
        byte[] h = new byte[64];
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            int n = r.read(h);
            if (n < 4) return fallbackForClass(videoClass);

            // PNG
            if (n >= 8 && u(h,0,8).equals("89504E470D0A1A0A"))
                return new Result(".png", "PNG image", "image/png");

            // JPEG/JPG
            if ((h[0]&255)==0xFF && (h[1]&255)==0xD8 && (h[2]&255)==0xFF)
                return new Result(".jpg", "JPEG image", "image/jpeg");

            // GIF
            if (ascii(h,0,6).equals("GIF87a") || ascii(h,0,6).equals("GIF89a"))
                return new Result(".gif", "GIF image", "image/gif");

            // BMP
            if (ascii(h,0,2).equals("BM"))
                return new Result(".bmp", "BMP image", "image/bmp");

            // TIFF
            if (ascii(h,0,4).equals("II*\0") || ascii(h,0,4).equals("MM\0*"))
                return new Result(".tiff", "TIFF image", "image/tiff");

            // WebP
            if (n >= 12 && ascii(h,0,4).equals("RIFF") && ascii(h,8,4).equals("WEBP"))
                return new Result(".webp", "WebP image", "image/webp");

            // AVI
            if (n >= 12 && ascii(h,0,4).equals("RIFF") && ascii(h,8,4).equals("AVI "))
                return new Result(".avi", "AVI video", "video/x-msvideo");

            // Matroska / WebM (EBML)
            if ((h[0]&255)==0x1A && (h[1]&255)==0x45 && (h[2]&255)==0xDF && (h[3]&255)==0xA3) {
                return new Result(".mkv", "Matroska / WebM video", "video/x-matroska");
            }

            // ISO Base Media: MP4/MOV/M4V/3GP. ftyp at byte 4.
            if (n >= 12 && ascii(h,4,4).equals("ftyp")) {
                String brand = ascii(h,8,4);
                if (brand.startsWith("heic") || brand.startsWith("heix") || brand.startsWith("hevc") || brand.startsWith("hevx"))
                    return new Result(".heic", "HEIC image", "image/heic");
                if (brand.equals("qt  ")) return new Result(".mov", "QuickTime MOV video", "video/quicktime");
                if (brand.equals("M4V ")) return new Result(".m4v", "M4V video", "video/x-m4v");
                if (brand.startsWith("3gp")) return new Result(".3gp", "3GP video", "video/3gpp");
                return new Result(".mp4", "MP4 video", "video/mp4");
            }

        }
        return fallbackForClass(videoClass);
    }

    public static Result fallbackForClass(boolean video) {
        return video
            ? new Result(".mp4", "Unknown video container — default MP4", "video/mp4")
            : new Result(".png", "Unknown image container — default PNG", "image/png");
    }

    private static String ascii(byte[] a, int off, int len) {
        if (off+len > a.length) return "";
        return new String(a, off, len, StandardCharsets.ISO_8859_1);
    }

    private static String u(byte[] a, int off, int len) {
        StringBuilder b=new StringBuilder();
        for(int i=off;i<off+len;i++) b.append(String.format("%02X",a[i]&255));
        return b.toString();
    }

    private FormatDetector() {}
}
