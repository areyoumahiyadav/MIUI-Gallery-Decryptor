package com.miui.clouddecryptor;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.util.concurrent.ThreadLocalRandom;

/** Optional local support notification. This is not a server push system. */
public final class SupportNotification {
    private static final String CHANNEL_ID = "support";
    private SupportNotification() {}

    public static void notifyUser(Context context) {
        if (Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        createChannel(context);
        String[] messages = {
                "Support the app by completing the rewarded ad before decrypting.",
                "Please use the official app and complete the support ad to unlock decryption.",
                "Ads help support continued development of MIUI Gallery Decryptor."
        };
        String text = messages[ThreadLocalRandom.current().nextInt(messages.length)];
        NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("MIUI Gallery Decryptor")
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);
        NotificationManagerCompat.from(context).notify(ThreadLocalRandom.current().nextInt(10000, 99999), b.build());
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "App support", NotificationManager.IMPORTANCE_DEFAULT));
    }
}
