# MIUI Gallery Decryptor — AdGate + Signature Detection Fix

## Rewarded ads

The project uses Google Mobile Ads. Debug builds intentionally use Google's official rewarded-ad test unit:

`ca-app-pub-3940256099942544/5224354917`

Release builds use the owner's production rewarded unit:

`ca-app-pub-4353440706315990/3691254959`

This is important: do **not** test production ads repeatedly while developing. Build `assembleDebug` first and verify the complete rewarded flow with the test ad. Real earnings require a properly signed release build and a live AdMob account/ad unit.

The app waits for the asynchronous Mobile Ads initialization and rewarded-ad load callback. A still-loading ad is not treated as an immediate failure. If the ad is unavailable, decryption remains locked.

## Signature detection

Signature detection is a **user-controlled media-format verification setting** and is ON by default. The Settings/Navigation dialog lets the user turn it ON or OFF and save the preference. It is not silently disabled by the app.

App-integrity protection is separate: the release build can verify its signing certificate before decryption. A modified/re-signed release build fails closed and cannot start the decryption engine.

Before publishing, replace `REPLACE_WITH_RELEASE_SHA256` in `IntegrityGuard.java` with the SHA-256 fingerprint of the final release signing certificate.

## Notifications

Android 13+ requires `POST_NOTIFICATIONS`. The app requests that permission when a support-ad gate is denied and can post a local support notification when permission is available. This is **not** Firebase push messaging.

Remote push notifications require Firebase Cloud Messaging and a Firebase project. Do not put server/private credentials in the APK.

## Build in Termux

```bash
gradle --version
java -version
cd miui
gradle assembleDebug
```

Debug APK:

`app/build/outputs/apk/debug/app-debug.apk`

For the real AdMob unit, build a signed release APK using your final release keystore after configuring the certificate fingerprint.
