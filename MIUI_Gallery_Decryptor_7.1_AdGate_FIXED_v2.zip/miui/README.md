# MIUI Gallery Decryptor 8.0 — Professional

Offline Android utility for authorized recovery of MIUI Gallery `.lsa` and `.lsav` files.

## Termux build
The project is configured for an Android SDK discovered by `build-termux.sh`.

```bash
chmod +x build-termux.sh
chmod +x build-termux.sh
bash build-termux.sh clean
bash build-termux.sh assembleDebug
```

The helper prefers `$HOME/android-sdk` and writes `local.properties` automatically. It does not force Termux's experimental AAPT2 unless `USE_TERMUX_AAPT2=1` is explicitly set.

## Rewarded-ad gate

Decryption is now fail-closed behind a Google AdMob rewarded ad. The supplied AdMob App ID and Rewarded Ad Unit ID are configured in the Android project.

- Ad not available / blocked: decryption remains locked.
- Ad dismissed before reward: decryption remains locked.
- Reward callback received: decryption starts.
- APK signed with a different certificate: decryption is disabled.

`IntegrityGuard.java` currently contains the SHA-256 certificate fingerprint of the APK supplied with the project. If the final release is signed with a different keystore, replace `EXPECTED_SHA256` with the SHA-256 fingerprint of that release certificate before distributing it.

For production anti-tamper protection, add Play Integrity verification with a server-side authorization endpoint. Local APK checks alone cannot provide cryptographic protection against a determined reverse engineer.
