# Termux build notes

The project uses the Android SDK at `$HOME/android-sdk` when available.
The build helper writes `local.properties` automatically.

## Build

```sh
chmod +x build-termux.sh
build-termux.sh clean
build-termux.sh assembleDebug
```

The script does **not** force Termux's `aapt2` by default. If you specifically need it:

```sh
USE_TERMUX_AAPT2=1 /build-termux.sh assembleDebug
```

The default is preferable because the Android Gradle Plugin selects a compatible aapt2.
